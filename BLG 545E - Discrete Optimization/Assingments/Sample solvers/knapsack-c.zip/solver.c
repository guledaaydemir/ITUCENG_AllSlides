#include <stdio.h>
#include <stdlib.h>
#include <time.h>


typedef struct item_s {
    int value;
    int weight;
} item_t;


typedef struct problem_s {
    item_t *items;
    int n_items;
    int capacity;
} problem_t;


typedef struct solution_s {
    int *taken;
    int value;
} solution_t;


problem_t *read_problem(const char *file_name)
{
    problem_t *problem = malloc(sizeof(problem_t));
    FILE *fp = fopen(file_name, "r");
    fscanf(fp, "%d %d", &(problem->n_items), &(problem->capacity));
    problem->items = malloc(problem->n_items * sizeof(item_t));

    int i = 0;
    for (i = 0; i < problem->n_items; i++)
        fscanf(fp, "%d %d", &(problem->items[i].value),
                            &(problem->items[i].weight));

    fclose(fp);
    return problem;
}


solution_t *solve(problem_t *problem, double p)
{
    solution_t *solution = malloc(sizeof(solution_t));
    solution->taken = malloc(problem->n_items * sizeof(int));
    solution->value = 0;

    int i = 0;
    for (i = 0; i < problem->n_items; i++) {
        if ((rand() / (double) RAND_MAX) < p) {
            solution->taken[i] = 1;
            solution->value += problem->items[i].value;
        } else {
            solution->taken[i] = 0;
        }
    }
    return solution;
}


int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Usage: %s input_file\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *file_name = argv[1];
    problem_t *problem = read_problem(file_name);

    // to be stochastic, set the seed from system time:
    srand(time(NULL));
    // to be deterministic, set a specific seed:
    // srand(799623108);

    solution_t *solution = solve(problem, 0.4);

    int i = 0;
    printf("%d\n", solution->value);
    printf("%d", solution->taken[i]);
    for (i = 1; i < problem->n_items; i++)
        printf(" %d", solution->taken[i]);
    printf("\n");

    free(problem->items);
    free(problem);
    free(solution->taken);
    free(solution);

    return EXIT_SUCCESS;
}
