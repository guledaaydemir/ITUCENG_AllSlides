import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;


class Item {
    private int _value;
    private int _weight;

    public Item(int value, int weight) {
        this._value = value;
        this._weight = weight;
    }

    public int getValue() {
        return this._value;
    }

    public int getWeight() {
        return this._weight;
    }
}


class Problem {
    private Item[] _items;
    private int _capacity;

    public Problem(String file_name) throws IOException {
        FileReader reader = new FileReader(file_name);
        BufferedReader input = new BufferedReader(reader);
        String line = input.readLine();
        String[] tokens = line.split("\\s+");
        int n_items = Integer.parseInt(tokens[0]);
        this._capacity = Integer.parseInt(tokens[1]);
        this._items = new Item[n_items];

        for (int i = 0; i < n_items; i++) {
            line = input.readLine();
            tokens = line.split("\\s+");
            int value = Integer.parseInt(tokens[0]);
            int weight = Integer.parseInt(tokens[1]);
            this._items[i] = new Item(value, weight);
        }
        input.close();
    }

    public Solution solve(double p) {
        int[] taken = new int[this._items.length];
        int value = 0;
        for (int i = 0; i < this._items.length; i++) {
            if (Solver.rng.nextDouble() < p) {
                taken[i] = 1;
                value += this._items[i].getValue();
            } else {
                taken[i] = 0;
            }
        }
        Solution solution = new Solution(taken, value);
        return solution;
    }
}


class Solution {
    private int[] _taken;
    private int _value;

    public Solution(int[] taken, int value) {
        this._taken = taken;
        this._value = value;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(String.format("%d\n", this._value));
        builder.append(String.format("%d", this._taken[0]));
        for (int i = 1; i < this._taken.length; i++)
            builder.append(String.format(" %d", this._taken[i]));
        return builder.toString();
    }
}


public class Solver {

    public static final Random rng = new Random();

    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            System.out.printf("Usage: java Solver input_file\n");
            System.exit(1);
        }
        String file_name = args[0];
        Problem problem = new Problem(file_name);

        // to be deterministic, set a specific seed:
        // Solver.rng.setSeed(799623108);

        Solution solution = problem.solve(0.4);
        System.out.println(solution);
    }
}
